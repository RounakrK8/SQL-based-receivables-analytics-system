-- =====================================================
-- Performance Optimization Indexes
-- Purpose: Improve query speed for reporting & analytics
-- =====================================================

-- Index for invoice-level customer & due date queries
CREATE INDEX idx_invoices_customer_due
ON invoices (customer_id, due_date);

-- Index for payment allocation joins
CREATE INDEX idx_invoice_payments_invoice_payment
ON invoice_payments (invoice_id, payment_id);

-- Index for customer payment history analysis
CREATE INDEX idx_payments_customer_date
ON payments (customer_id, payment_date);

