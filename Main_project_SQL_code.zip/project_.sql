CREATE DATABASE finance;
USE finance;

CREATE TABLE stg_customers (
    customer_id      INT,
    customer_name    VARCHAR(255),
    customer_segment VARCHAR(50),
    country           VARCHAR(100),
    credit_limit     DECIMAL(12,2),
    status            VARCHAR(20),
    created_date_raw VARCHAR(20)
);
CREATE TABLE stg_invoices (
    invoice_id        INT,
    customer_id       INT,
    invoice_date_raw  VARCHAR(20),
    due_date_raw      VARCHAR(20),
    invoice_amount    DECIMAL(12,2),
    invoice_type      VARCHAR(30),
    invoice_status    VARCHAR(30),
    currency          VARCHAR(10),
    created_at_raw    VARCHAR(20)
);
CREATE TABLE stg_payments (
    payment_id        INT,
    customer_id       INT,
    payment_date_raw  VARCHAR(20),
    payment_amount    DECIMAL(12,2),
    payment_method    VARCHAR(30),
    payment_status    VARCHAR(30),
    reference_no      CHAR(36)
);
CREATE TABLE stg_invoice_payments (
    allocation_id     INT,
    invoice_id        INT,
    payment_id        INT,
    applied_amount    DECIMAL(12,2),
    allocation_date_raw VARCHAR(20)
);
CREATE TABLE stg_dunning_actions (
    dunning_id        INT,
    invoice_id        INT,
    action_date_raw   VARCHAR(20),
    action_type       VARCHAR(30),
    action_result     VARCHAR(30)
);
CREATE TABLE stg_credit_notes (
    credit_note_id       INT,
    original_invoice_id  INT,
    customer_id          INT,
    credit_date_raw      VARCHAR(20),
    credit_amount        DECIMAL(12,2),
    reason               VARCHAR(100)
);



CREATE TABLE customers (
    customer_id      INT PRIMARY KEY,
    customer_name    VARCHAR(255) NOT NULL,
    customer_segment VARCHAR(50) NOT NULL,
    country          VARCHAR(100) NOT NULL,
    credit_limit     DECIMAL(12,2) NOT NULL,
    status           VARCHAR(20) NOT NULL,
    created_date     DATE NOT NULL
);

CREATE TABLE invoices (
    invoice_id      INT PRIMARY KEY,
    customer_id     INT NOT NULL,
    invoice_date    DATE NOT NULL,
    due_date        DATE,
    invoice_amount  DECIMAL(12,2) NOT NULL,
    invoice_type    VARCHAR(30) NOT NULL,
    invoice_status  VARCHAR(30) NOT NULL,
    currency        VARCHAR(10) NOT NULL,
    created_at      DATE NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE payments (
    payment_id      INT PRIMARY KEY,
    customer_id     INT NOT NULL,
    payment_date    DATE NOT NULL,
    payment_amount  DECIMAL(12,2) NOT NULL,
    payment_method  VARCHAR(30) NOT NULL,
    payment_status  VARCHAR(30) NOT NULL,
    reference_no    CHAR(36) NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE invoice_payments (
    allocation_id   INT PRIMARY KEY,
    invoice_id      INT NOT NULL,
    payment_id      INT NOT NULL,
    applied_amount  DECIMAL(12,2) NOT NULL,
    allocation_date DATE NOT NULL,
    FOREIGN KEY (invoice_id) REFERENCES invoices(invoice_id),
    FOREIGN KEY (payment_id) REFERENCES payments(payment_id)
);

CREATE TABLE dunning_actions (
    dunning_id    INT PRIMARY KEY,
    invoice_id    INT NOT NULL,
    action_date   DATE NOT NULL,
    action_type   VARCHAR(30) NOT NULL,
    action_result VARCHAR(30) NOT NULL,
    FOREIGN KEY (invoice_id) REFERENCES invoices(invoice_id)
);

CREATE TABLE credit_notes (
    credit_note_id      INT PRIMARY KEY,
    original_invoice_id INT NOT NULL,
    customer_id         INT NOT NULL,
    credit_date         DATE NOT NULL,
    credit_amount       DECIMAL(12,2) NOT NULL,
    reason              VARCHAR(100),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (original_invoice_id) REFERENCES invoices(invoice_id)
);
-- NOW DATA CLEANING and transformation 
INSERT INTO customers
SELECT
    customer_id,
    customer_name,
    customer_segment,
    country,
    credit_limit,
    status,
    CASE
        WHEN created_date_raw LIKE '%/%' THEN STR_TO_DATE(created_date_raw, '%m/%d/%Y')
        WHEN created_date_raw LIKE '%-%' THEN STR_TO_DATE(created_date_raw, '%d-%m-%Y')
    END
FROM stg_customers;

INSERT INTO invoices
SELECT
    invoice_id,
    customer_id,
    CASE
        WHEN invoice_date_raw LIKE '%/%' THEN STR_TO_DATE(invoice_date_raw, '%m/%d/%Y')
        WHEN invoice_date_raw LIKE '%-%' THEN STR_TO_DATE(invoice_date_raw, '%d-%m-%Y')
    END,
    CASE
        WHEN due_date_raw LIKE '%/%' THEN STR_TO_DATE(due_date_raw, '%m/%d/%Y')
        WHEN due_date_raw LIKE '%-%' THEN STR_TO_DATE(due_date_raw, '%d-%m-%Y')
    END,
    invoice_amount,
    invoice_type,
    invoice_status,
    currency,
    CASE
        WHEN created_at_raw LIKE '%/%' THEN STR_TO_DATE(created_at_raw, '%m/%d/%Y')
        WHEN created_at_raw LIKE '%-%' THEN STR_TO_DATE(created_at_raw, '%d-%m-%Y')
    END
FROM stg_invoices;

INSERT INTO payments
SELECT
    payment_id,
    customer_id,
    CASE
        WHEN payment_date_raw LIKE '%/%' THEN STR_TO_DATE(payment_date_raw, '%m/%d/%Y')
        WHEN payment_date_raw LIKE '%-%' THEN STR_TO_DATE(payment_date_raw, '%d-%m-%Y')
    END,
    payment_amount,
    payment_method,
    payment_status,
    reference_no
FROM stg_payments;

INSERT INTO invoice_payments
SELECT
    allocation_id,
    invoice_id,
    payment_id,
    applied_amount,
    CASE
        WHEN allocation_date_raw LIKE '%/%' THEN STR_TO_DATE(allocation_date_raw, '%m/%d/%Y')
        WHEN allocation_date_raw LIKE '%-%' THEN STR_TO_DATE(allocation_date_raw, '%d-%m-%Y')
    END
FROM stg_invoice_payments;

INSERT INTO dunning_actions
SELECT
    dunning_id,
    invoice_id,
    CASE
        WHEN action_date_raw LIKE '%/%' THEN STR_TO_DATE(action_date_raw, '%m/%d/%Y')
        WHEN action_date_raw LIKE '%-%' THEN STR_TO_DATE(action_date_raw, '%d-%m-%Y')
    END,
    action_type,
    action_result
FROM stg_dunning_actions;

INSERT INTO credit_notes
SELECT
    credit_note_id,
    original_invoice_id,
    customer_id,
    CASE
        WHEN credit_date_raw LIKE '%/%' THEN STR_TO_DATE(credit_date_raw, '%m/%d/%Y')
        WHEN credit_date_raw LIKE '%-%' THEN STR_TO_DATE(credit_date_raw, '%d-%m-%Y')
    END,
    credit_amount,
    reason
FROM stg_credit_notes;

DROP TABLE IF EXISTS
    stg_invoice_payments,
    stg_dunning_actions,
    stg_credit_notes,
    stg_payments,
    stg_invoices,
    stg_customers;

-- source of truth 

CREATE OR REPLACE VIEW invoice_balance AS
SELECT
    i.invoice_id,
    i.customer_id,
    i.invoice_date,
    i.due_date,
    i.invoice_amount,

    /* Raw applied amount (for audit & transparency) */
    COALESCE(SUM(ip.applied_amount), 0) AS total_applied_raw,

    /* Applied amount capped at invoice value */
    LEAST(
        COALESCE(SUM(ip.applied_amount), 0),
        i.invoice_amount
    ) AS total_applied,

    /* Extra money paid beyond invoice amount */
    GREATEST(
        COALESCE(SUM(ip.applied_amount), 0) - i.invoice_amount,
        0
    ) AS customer_credit,

    /* Remaining unpaid balance (never negative) */
    GREATEST(
        i.invoice_amount -
        LEAST(COALESCE(SUM(ip.applied_amount), 0), i.invoice_amount),
        0
    ) AS open_balance,

    /* Days past due */
    CASE
        WHEN
            GREATEST(
                i.invoice_amount -
                LEAST(COALESCE(SUM(ip.applied_amount), 0), i.invoice_amount),
                0
            ) > 0
            AND CURRENT_DATE > i.due_date
        THEN DATEDIFF(CURRENT_DATE, i.due_date)
        ELSE 0
    END AS days_past_due,

    /* Date when invoice became fully paid */
    CASE
        WHEN
            GREATEST(
                i.invoice_amount -
                LEAST(COALESCE(SUM(ip.applied_amount), 0), i.invoice_amount),
                0
            ) = 0
        THEN MAX(p.payment_date)
        ELSE NULL
    END AS paid_date

FROM invoices i

LEFT JOIN invoice_payments ip
    ON i.invoice_id = ip.invoice_id

LEFT JOIN payments p
    ON ip.payment_id = p.payment_id
   AND p.payment_status = 'SUCCESS'

GROUP BY
    i.invoice_id,
    i.customer_id,
    i.invoice_date,
    i.due_date,
    i.invoice_amount;

select * from invoice_balance;

-- customer_ar_snapshot (per customer)

CREATE VIEW customer_ar_snapshot AS
SELECT
    i.customer_id,

    CASE
        WHEN days_past_due = 0 THEN 'Current'
        WHEN days_past_due BETWEEN 1 AND 30 THEN '1–30 Days Overdue'
        WHEN days_past_due BETWEEN 31 AND 60 THEN '31–60 Days Overdue'
        ELSE '60+ Days Overdue'
    END AS overdue_bucket,

    SUM(open_balance) AS open_ar 
    ,
       ROUND(
        SUM(open_balance) / NULLIF(credit_limit, 0),
        2
    ) AS credit_utilization_ratio

FROM invoice_balance i 
join customers c 
on i.customer_id = c.customer_id
GROUP BY
    i.customer_id,
    CASE
        WHEN days_past_due = 0 THEN 'Current'
        WHEN days_past_due BETWEEN 1 AND 30 THEN '1–30 Days Overdue'
        WHEN days_past_due BETWEEN 31 AND 60 THEN '31–60 Days Overdue'
        ELSE '60+ Days Overdue'
    END;

-- Build DSO
CREATE VIEW DSO AS
WITH month_sales AS (
    SELECT
        DATE_FORMAT(invoice_date, '%Y-%m-01') AS month_start,
        SUM(invoice_amount) AS monthly_sales
    FROM invoices
    GROUP BY DATE_FORMAT(invoice_date, '%Y-%m-01')
),

month_end_ar AS (
    SELECT
        ms.month_start,
        SUM(ib.open_balance) AS ar_end_of_month
    FROM month_sales ms
    JOIN invoice_balance ib
        ON ib.invoice_date <= LAST_DAY(ms.month_start)
       AND (
            ib.paid_date IS NULL
            OR ib.paid_date > LAST_DAY(ms.month_start)
       )
    GROUP BY ms.month_start
)
SELECT
    DATE_FORMAT(ms.month_start, '%Y-%m') AS month,
    ms.monthly_sales,
    COALESCE(ar.ar_end_of_month, 0) AS ar_end_of_month,

    ROUND(
        (COALESCE(ar.ar_end_of_month, 0) / NULLIF(ms.monthly_sales, 0))
        * DAY(LAST_DAY(ms.month_start)),
        2
    ) AS dso

FROM month_sales ms
LEFT JOIN month_end_ar ar
    ON ms.month_start = ar.month_start

ORDER BY month;
select * from DSO;

--  Analyzing collections effectiveness

WITH action_outcomes AS (
    SELECT
        da.dunning_id,
        da.invoice_id,
        da.action_type,
        da.action_date,

        c.customer_segment,

        ib.paid_date,

        /* Days taken to pay after action */
        DATEDIFF(ib.paid_date, da.action_date) AS days_to_pay,

        /* Payment within time windows */
        CASE
            WHEN ib.paid_date IS NOT NULL
                 AND ib.paid_date <= da.action_date + INTERVAL 7 DAY
            THEN 1 ELSE 0
        END AS paid_within_7_days,

        CASE
            WHEN ib.paid_date IS NOT NULL
                 AND ib.paid_date <= da.action_date + INTERVAL 14 DAY
            THEN 1 ELSE 0
        END AS paid_within_14_days,

        CASE
            WHEN ib.paid_date IS NOT NULL
                 AND ib.paid_date <= da.action_date + INTERVAL 30 DAY
            THEN 1 ELSE 0
        END AS paid_within_30_days

    FROM dunning_actions da
    JOIN invoices i
        ON da.invoice_id = i.invoice_id
    JOIN customers c
        ON i.customer_id = c.customer_id
    JOIN invoice_balance ib
        ON da.invoice_id = ib.invoice_id
)
SELECT
    action_type,
    customer_segment,

    COUNT(*) AS total_actions,

    ROUND(AVG(paid_within_7_days) * 100, 2) AS success_rate_7_days,
    ROUND(AVG(paid_within_14_days) * 100, 2) AS success_rate_14_days,
    ROUND(AVG(paid_within_30_days) * 100, 2) AS success_rate_30_days,

    ROUND(AVG(days_to_pay), 2) AS avg_days_to_pay_after_action

FROM action_outcomes
GROUP BY
    action_type,
    customer_segment
ORDER BY
    action_type,
    customer_segment;


--  the Risk List 
create view Risk_list as
WITH customer_risk_features AS (
    SELECT
        ib.customer_id,

        /* Total overdue amount */
        SUM(
            CASE
                WHEN ib.days_past_due > 0 THEN ib.open_balance
                ELSE 0
            END
        ) AS total_overdue_amount,

        /* Amount overdue more than 90 days */
        SUM(
            CASE
                WHEN ib.days_past_due > 90 THEN ib.open_balance
                ELSE 0
            END
        ) AS overdue_90_plus_amount,

        /* Number of overdue invoices */
        COUNT(
            CASE
                WHEN ib.days_past_due > 0 THEN ib.invoice_id
            END
        ) AS overdue_invoice_count

    FROM invoice_balance ib
    GROUP BY ib.customer_id
),
failed_payments AS (
    SELECT
        p.customer_id,
        COUNT(*) AS failed_payments_last_60_days
    FROM payments p
    WHERE p.payment_status IN ('FAILED', 'REVERSED')
      AND p.payment_date >= CURRENT_DATE - INTERVAL 60 DAY
    GROUP BY p.customer_id
),
credit_utilization AS (
    SELECT
        c.customer_id,
        CASE
            WHEN SUM(ib.open_balance) > c.credit_limit THEN 1
            ELSE 0
        END AS credit_limit_exceeded
    FROM customers c
    LEFT JOIN invoice_balance ib
        ON c.customer_id = ib.customer_id
    GROUP BY
        c.customer_id,
        c.credit_limit
)
SELECT
    c.customer_id,
    c.customer_name,
    c.customer_segment,

    /* Risk features */
    COALESCE(crf.total_overdue_amount, 0) AS total_overdue_amount,
    COALESCE(crf.overdue_90_plus_amount, 0) AS overdue_90_plus_amount,
    COALESCE(crf.overdue_invoice_count, 0) AS overdue_invoice_count,
    COALESCE(fp.failed_payments_last_60_days, 0) AS failed_payments_last_60_days,
    cu.credit_limit_exceeded,

    /* Simple risk score */
    (
        CASE WHEN COALESCE(crf.total_overdue_amount, 0) > 0 THEN 1 ELSE 0 END +
        CASE WHEN COALESCE(crf.overdue_90_plus_amount, 0) > 0 THEN 2 ELSE 0 END +
        CASE WHEN COALESCE(crf.overdue_invoice_count, 0) >= 3 THEN 1 ELSE 0 END +
        CASE WHEN COALESCE(fp.failed_payments_last_60_days, 0) > 0 THEN 1 ELSE 0 END +
        CASE WHEN cu.credit_limit_exceeded = 1 THEN 2 ELSE 0 END
    ) AS risk_score

FROM customers c
LEFT JOIN customer_risk_features crf
    ON c.customer_id = crf.customer_id
LEFT JOIN failed_payments fp
    ON c.customer_id = fp.customer_id
LEFT JOIN credit_utilization cu
    ON c.customer_id = cu.customer_id

ORDER BY risk_score DESC;
select * from Risk_list;
-- Data Quality & Anomaly Checks (Deliverable #5)

SELECT
    reference_no,
    COUNT(*) AS occurrence_count
FROM payments
GROUP BY reference_no
HAVING COUNT(*) > 1;

SELECT
    p.payment_id,
    p.payment_amount,
    SUM(ip.applied_amount) AS total_applied_amount
FROM payments p
JOIN invoice_payments ip
    ON p.payment_id = ip.payment_id
GROUP BY
    p.payment_id,
    p.payment_amount
HAVING total_applied_amount > p.payment_amount;

SELECT
    ip.allocation_id,
    ip.payment_id,
    p.payment_status
FROM invoice_payments ip
JOIN payments p
    ON ip.payment_id = p.payment_id
WHERE p.payment_status IN ('FAILED', 'REVERSED');

SELECT
    i.invoice_id,
    i.invoice_status,
    ib.open_balance
FROM invoices i
JOIN invoice_balance ib
    ON i.invoice_id = ib.invoice_id
WHERE i.invoice_status = 'PAID'
  AND ib.open_balance > 0;

SELECT
    ip.allocation_id,
    ip.invoice_id,
    i.invoice_status
FROM invoice_payments ip
JOIN invoices i
    ON ip.invoice_id = i.invoice_id
WHERE i.invoice_status = 'VOID';

